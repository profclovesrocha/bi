# ============================================================
# AV2 - Business Intelligence
# Projeto: SAD Alfabetizando com AlegrIA
# Dashboard/Protótipo de Business Intelligence em Python
# ============================================================

import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import webbrowser
import os

arquivo = "Base_Dados_Alfabetizando_AlegrIA_BI.xlsx"

# ============================================================
# 1. Carregar os dados ou criar base simulada
# ============================================================

try:
    df = pd.read_excel(arquivo, sheet_name="Base_Dados")
except:
    print("Arquivo não encontrado. Criando base simulada automaticamente...")

    import numpy as np
    np.random.seed(42)

    qtd = 120

    df = pd.DataFrame({
        "ID_Paciente": range(1, qtd + 1),
        "Codigo_Anonimo": [f"PAC_{i:03d}" for i in range(1, qtd + 1)],
        "Faixa_Etaria": np.random.choice(["4 a 6 anos", "7 a 9 anos", "10 a 12 anos"], qtd),
        "Ano_Escolar": np.random.choice(["Educação Infantil", "1º Ano", "2º Ano", "3º Ano"], qtd),
        "Hospital": np.random.choice(["IMIP", "Hospital Infantil Parceiro"], qtd),
        "Ala": np.random.choice(["Pediatria", "Oncologia", "Enfermaria", "UTI Pediátrica"], qtd),
        "Tipo_Atividade": np.random.choice(["Leitura", "Escrita", "Sílabas", "Interpretação", "Jogo Educativo"], qtd),
        "Nivel_Dificuldade": np.random.choice(["Fácil", "Médio", "Difícil"], qtd),
        "Tempo_Uso_IA_Minutos": np.random.randint(10, 121, qtd),
        "Qtd_Atividades_Realizadas": np.random.randint(1, 16, qtd),
        "Percentual_Acertos": np.random.randint(35, 101, qtd),
        "Indice_Continuidade_Escolar": np.random.uniform(0.35, 1.00, qtd).round(2),
        "Taxa_Alfabetizacao_Digital": np.random.uniform(0.30, 1.00, qtd).round(2),
        "Sentimento_Familia": np.random.choice(["Positivo", "Neutro", "Negativo"], qtd, p=[0.65, 0.25, 0.10])
    })

# ============================================================
# 2. Padronizar nomes das colunas
# ============================================================

df.columns = (
    df.columns
    .str.strip()
    .str.replace(" ", "_")
    .str.replace("-", "_")
)

# ============================================================
# 3. Tratamento básico dos dados
# ============================================================

df = df.drop_duplicates()

colunas_numericas = [
    "Tempo_Uso_IA_Minutos",
    "Qtd_Atividades_Realizadas",
    "Percentual_Acertos",
    "Indice_Continuidade_Escolar",
    "Taxa_Alfabetizacao_Digital"
]

for coluna in colunas_numericas:
    if coluna in df.columns:
        df[coluna] = pd.to_numeric(df[coluna], errors="coerce")
        df[coluna] = df[coluna].fillna(df[coluna].median())

# ============================================================
# 4. Criar classificação de engajamento
# ============================================================

def classificar_engajamento(linha):
    if (
        linha["Tempo_Uso_IA_Minutos"] >= 70 and
        linha["Qtd_Atividades_Realizadas"] >= 8 and
        linha["Percentual_Acertos"] >= 70
    ):
        return "Alto engajamento"
    elif (
        linha["Tempo_Uso_IA_Minutos"] >= 35 and
        linha["Qtd_Atividades_Realizadas"] >= 4 and
        linha["Percentual_Acertos"] >= 50
    ):
        return "Médio engajamento"
    else:
        return "Baixo engajamento"

if "Nivel_Engajamento" not in df.columns:
    df["Nivel_Engajamento"] = df.apply(classificar_engajamento, axis=1)

# ============================================================
# 5. Criar coluna de evolução pedagógica
# ============================================================

if "Evolucao_Pedagogica" not in df.columns:
    df["Evolucao_Pedagogica"] = (
        (df["Percentual_Acertos"] * 0.50) +
        (df["Indice_Continuidade_Escolar"] * 100 * 0.25) +
        (df["Taxa_Alfabetizacao_Digital"] * 100 * 0.25)
    ).round(2)

# ============================================================
# 6. Cálculo dos KPIs
# ============================================================

total_pacientes = df["ID_Paciente"].nunique()
media_acertos = df["Percentual_Acertos"].mean()
continuidade_media = df["Indice_Continuidade_Escolar"].mean() * 100
alfabetizacao_digital_media = df["Taxa_Alfabetizacao_Digital"].mean() * 100
tempo_medio_ia = df["Tempo_Uso_IA_Minutos"].mean()
evolucao_media = df["Evolucao_Pedagogica"].mean()
sentimento_positivo = df[df["Sentimento_Familia"] == "Positivo"].shape[0]

# ============================================================
# 7. Tabelas para os gráficos
# ============================================================

engajamento_counts = df["Nivel_Engajamento"].value_counts()
sentimento_counts = df["Sentimento_Familia"].value_counts()
atividade_counts = df["Tipo_Atividade"].value_counts()
pacientes_por_hospital = df["Hospital"].value_counts()

acertos_por_engajamento = (
    df.groupby("Nivel_Engajamento")["Percentual_Acertos"]
    .mean()
    .sort_values()
)

evolucao_por_atividade = (
    df.groupby("Tipo_Atividade")["Evolucao_Pedagogica"]
    .mean()
    .sort_values()
)

tempo_por_ala = (
    df.groupby("Ala")["Tempo_Uso_IA_Minutos"]
    .mean()
    .sort_values()
)

continuidade_por_faixa = (
    df.groupby("Faixa_Etaria")["Indice_Continuidade_Escolar"]
    .mean()
    .sort_values() * 100
)

# ============================================================
# 8. Criar Dashboard Interativo
# ============================================================

fig = make_subplots(
    rows=4,
    cols=2,
    subplot_titles=(
        "1. Pacientes por Nível de Engajamento",
        "2. Sentimento das Famílias",
        "3. Pacientes por Hospital",
        "4. Percentual Médio de Acertos por Engajamento",
        "5. Evolução Pedagógica por Tipo de Atividade",
        "6. Tempo Médio de Uso da IA por Ala",
        "7. Continuidade Escolar por Faixa Etária",
        "8. Atividades Realizadas por Tipo"
    ),
    specs=[
        [{"type": "domain"}, {"type": "domain"}],
        [{"type": "domain"}, {"type": "xy"}],
        [{"type": "xy"}, {"type": "xy"}],
        [{"type": "xy"}, {"type": "domain"}]
    ]
)

fig.add_trace(
    go.Pie(
        labels=engajamento_counts.index,
        values=engajamento_counts.values,
        hole=0.35,
        textinfo="label+percent"
    ),
    row=1, col=1
)

fig.add_trace(
    go.Pie(
        labels=sentimento_counts.index,
        values=sentimento_counts.values,
        hole=0.35,
        textinfo="label+percent"
    ),
    row=1, col=2
)

fig.add_trace(
    go.Pie(
        labels=pacientes_por_hospital.index,
        values=pacientes_por_hospital.values,
        hole=0.35,
        textinfo="label+percent"
    ),
    row=2, col=1
)

fig.add_trace(
    go.Bar(
        x=acertos_por_engajamento.index,
        y=acertos_por_engajamento.values,
        text=acertos_por_engajamento.round(1).values,
        textposition="auto"
    ),
    row=2, col=2
)

fig.add_trace(
    go.Bar(
        x=evolucao_por_atividade.index,
        y=evolucao_por_atividade.values,
        text=evolucao_por_atividade.round(1).values,
        textposition="auto"
    ),
    row=3, col=1
)

fig.add_trace(
    go.Bar(
        x=tempo_por_ala.index,
        y=tempo_por_ala.values,
        text=tempo_por_ala.round(1).values,
        textposition="auto"
    ),
    row=3, col=2
)

fig.add_trace(
    go.Bar(
        x=continuidade_por_faixa.index,
        y=continuidade_por_faixa.values,
        text=continuidade_por_faixa.round(1).values,
        textposition="auto"
    ),
    row=4, col=1
)

fig.add_trace(
    go.Pie(
        labels=atividade_counts.index,
        values=atividade_counts.values,
        hole=0.45,
        textinfo="label+value"
    ),
    row=4, col=2
)

# ============================================================
# 9. Layout geral
# ============================================================

fig.update_layout(
    title_text=(
        "Dashboard SAD Alfabetizando com AlegrIA<br>"
        "<sup>Protótipo de Sistema de Apoio à Decisão para acompanhamento da alfabetização hospitalar com IA</sup>"
    ),
    height=1450,
    showlegend=False,
    template="plotly_white"
)

fig.update_xaxes(title_text="Nível de Engajamento", row=2, col=2)
fig.update_yaxes(title_text="Percentual Médio de Acertos", row=2, col=2)

fig.update_xaxes(title_text="Tipo de Atividade", row=3, col=1)
fig.update_yaxes(title_text="Evolução Pedagógica Média", row=3, col=1)

fig.update_xaxes(title_text="Ala Hospitalar", row=3, col=2)
fig.update_yaxes(title_text="Tempo Médio de Uso da IA", row=3, col=2)

fig.update_xaxes(title_text="Faixa Etária", row=4, col=1)
fig.update_yaxes(title_text="Continuidade Escolar Média (%)", row=4, col=1)

# ============================================================
# 10. Criar cards de KPIs em HTML
# ============================================================

cards_html = f"""
<div style="display:flex; flex-wrap:wrap; gap:15px; margin-bottom:20px; font-family:Arial;">
    <div style="flex:1; min-width:180px; background:#f2f6ff; padding:18px; border-radius:12px; text-align:center;">
        <h3>Total de Pacientes</h3>
        <h2>{total_pacientes}</h2>
    </div>
    <div style="flex:1; min-width:180px; background:#f4fff6; padding:18px; border-radius:12px; text-align:center;">
        <h3>Média de Acertos</h3>
        <h2>{media_acertos:.2f}%</h2>
    </div>
    <div style="flex:1; min-width:180px; background:#fffaf0; padding:18px; border-radius:12px; text-align:center;">
        <h3>Continuidade Escolar</h3>
        <h2>{continuidade_media:.2f}%</h2>
    </div>
    <div style="flex:1; min-width:180px; background:#f7f0ff; padding:18px; border-radius:12px; text-align:center;">
        <h3>Alfabetização Digital</h3>
        <h2>{alfabetizacao_digital_media:.2f}%</h2>
    </div>
    <div style="flex:1; min-width:180px; background:#fff4f4; padding:18px; border-radius:12px; text-align:center;">
        <h3>Tempo Médio de IA</h3>
        <h2>{tempo_medio_ia:.1f} min</h2>
    </div>
    <div style="flex:1; min-width:180px; background:#eefcff; padding:18px; border-radius:12px; text-align:center;">
        <h3>Evolução Pedagógica</h3>
        <h2>{evolucao_media:.2f}</h2>
    </div>
</div>
"""

explicacao_html = """
<div style="font-family:Arial; margin-top:20px; margin-bottom:20px; line-height:1.5;">
    <h2></h2>
    <p>
    </p>

    <h2></h2>
    <ul>
    </ul>

    <h2></h2>
    <p>
    </p>
</div>
"""

html_dashboard = f"""
<html>
<head>
    <meta charset="utf-8">
    <title>Dashboard SAD Alfabetizando com AlegrIA</title>
</head>
<body>
    <h1 style="font-family:Arial;">AV2 Business Intelligence - SAD Alfabetizando com AlegrIA</h1>
    {cards_html}
    {explicacao_html}
    {fig.to_html(full_html=False, include_plotlyjs="cdn")}
</body>
</html>
"""

# ============================================================
# 11. Salvar e abrir dashboard
# ============================================================

nome_arquivo = "dashboard_bi_alfabetizando_alegria.html"

with open(nome_arquivo, "w", encoding="utf-8") as f:
    f.write(html_dashboard)

caminho = os.path.abspath(nome_arquivo)

print("Dashboard gerado com sucesso!")
print("Arquivo criado em:", caminho)

webbrowser.open("file://" + caminho)
